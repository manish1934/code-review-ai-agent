from langchain_groq import ChatGroq
from langchain.prompts import ChatPromptTemplate
from rag.retriever import retrieve_context
import os
from dotenv import load_dotenv

load_dotenv()

def run_bug_detector(code: str) -> str:
    llm = ChatGroq(
        model="llama3-70b-8192",
        api_key=os.getenv("GROQ_API_KEY"),
        temperature=0
    )

    context = retrieve_context(f"common bugs python errors: {code[:200]}")

    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are an expert Bug Detector agent. Analyze the given code and identify:
- Logic errors and off-by-one mistakes
- Null/None pointer issues
- Exception handling problems
- Memory leaks or resource mismanagement
- Incorrect data type usage

Use this reference context from best practices:
{context}

Be specific — mention exact line numbers or variable names when possible.
Format your response as a numbered list of bugs found. If no bugs, say 'No bugs detected.'"""),
        ("human", "Review this code for bugs:\n\n```\n{code}\n```")
    ])

    chain = prompt | llm
    result = chain.invoke({"code": code, "context": context})
    return result.content
