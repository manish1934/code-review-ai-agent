import os
from pathlib import Path
from langchain_community.document_loaders import TextLoader, PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import SentenceTransformerEmbeddings

CHROMA_DIR = "./chroma_db"
KNOWLEDGE_DIR = "./rag/knowledge_base"

def get_embeddings():
    return SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

def load_documents():
    docs = []
    kb_path = Path(KNOWLEDGE_DIR)
    for file in kb_path.glob("**/*"):
        if file.suffix == ".txt":
            loader = TextLoader(str(file))
            docs.extend(loader.load())
        elif file.suffix == ".pdf":
            loader = PyPDFLoader(str(file))
            docs.extend(loader.load())
    return docs

def ingest():
    print("Loading documents...")
    docs = load_documents()

    if not docs:
        print("No docs found. Adding default coding best practices...")
        from langchain.schema import Document
        docs = [
            Document(page_content="""
Python Best Practices (PEP8):
- Use 4 spaces for indentation, never tabs
- Maximum line length is 79 characters
- Use snake_case for variables and functions
- Use PascalCase for class names
- Always handle exceptions explicitly — never use bare except
- Use context managers (with statement) for file operations
- Avoid mutable default arguments in function definitions
- Write docstrings for all public functions and classes
""", metadata={"source": "pep8", "category": "style"}),
            Document(page_content="""
OWASP Top 10 Security Vulnerabilities:
1. SQL Injection: Never concatenate user input into SQL queries. Always use parameterized queries.
2. Broken Authentication: Use secure session management, enforce strong passwords.
3. XSS (Cross-Site Scripting): Sanitize and escape all user input before rendering.
4. Insecure Direct Object References: Validate user access before exposing object IDs.
5. Security Misconfiguration: Disable debug mode in production, remove default credentials.
6. Sensitive Data Exposure: Encrypt sensitive data at rest and in transit (TLS/HTTPS).
7. Missing Function-Level Access Control: Always verify authorization server-side.
8. CSRF: Use anti-CSRF tokens for state-changing requests.
9. Using Components with Known Vulnerabilities: Keep all dependencies updated.
10. Unvalidated Redirects: Avoid redirects based on unvalidated user input.
""", metadata={"source": "owasp", "category": "security"}),
            Document(page_content="""
Code Performance Best Practices:
- Avoid nested loops when possible — prefer list comprehensions or vectorized operations
- Use generators for large datasets to avoid loading everything into memory
- Cache expensive function calls using functools.lru_cache
- Use appropriate data structures: dict for O(1) lookups, set for membership checks
- Profile before optimizing — use cProfile or line_profiler
- Avoid global variables as they slow down lookups
- Use local variable references inside tight loops
- Prefer built-in functions (map, filter, sum) over manual loops
- Use lazy evaluation where possible
""", metadata={"source": "performance", "category": "optimization"}),
            Document(page_content="""
Common Bug Patterns in Python:
- Off-by-one errors in list slicing and range()
- Mutable default arguments causing shared state between calls
- Late binding closures in lambda/loop combinations
- Shallow copy vs deep copy confusion with nested objects
- Integer division vs float division (use // for integer division explicitly)
- NoneType errors — always check if a value can be None before accessing attributes
- String immutability — string concatenation in loops is O(n²), use join() instead
- Exception swallowing — catching broad exceptions hides real bugs
- Race conditions in multi-threaded code — use locks or queues
""", metadata={"source": "bugs", "category": "debugging"}),
        ]

    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    chunks = splitter.split_documents(docs)

    print(f"Created {len(chunks)} chunks from {len(docs)} documents")
    print("Embedding and storing in ChromaDB...")

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=get_embeddings(),
        persist_directory=CHROMA_DIR
    )

    print(f"Done! {len(chunks)} chunks stored in ChromaDB.")
    return vectorstore

def get_vectorstore():
    embeddings = get_embeddings()
    if Path(CHROMA_DIR).exists():
        return Chroma(persist_directory=CHROMA_DIR, embedding_function=embeddings)
    return ingest()

if __name__ == "__main__":
    ingest()
