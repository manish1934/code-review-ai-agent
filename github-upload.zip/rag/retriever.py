from rag.ingest import get_vectorstore

def retrieve_context(query: str, k: int = 4) -> str:
    vectorstore = get_vectorstore()
    docs = vectorstore.similarity_search(query, k=k)
    context = "\n\n".join([doc.page_content for doc in docs])
    return context
