def simple_eval(code: str, review: str) -> dict:
    """
    Lightweight evaluation without full RAGAS setup.
    For full RAGAS eval, replace with ragas library calls.
    """
    scores = {}

    # Relevancy: does review mention code-specific terms?
    code_keywords = set(code.split())
    review_words = set(review.lower().split())
    common = code_keywords & review_words
    scores["relevancy"] = min(1.0, len(common) / max(len(code_keywords), 1))

    # Coverage: checks if key sections are present
    sections = ["bug", "security", "optim", "score", "verdict"]
    found = sum(1 for s in sections if s in review.lower())
    scores["coverage"] = found / len(sections)

    # Length quality: too short = low quality
    scores["completeness"] = min(1.0, len(review) / 500)

    scores["overall"] = round(
        (scores["relevancy"] * 0.3 +
         scores["coverage"] * 0.4 +
         scores["completeness"] * 0.3), 2
    )

    return scores
